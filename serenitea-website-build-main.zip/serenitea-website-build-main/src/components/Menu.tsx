import { Card, CardContent } from '@/components/ui/card';
import icedTea from '@/assets/iced-tea.jpg';
import smoothie from '@/assets/smoothie.jpg';
import coffee from '@/assets/coffee.jpg';
import herbalTea from '@/assets/herbal-tea.jpg';

const Menu = () => {
  const menuCategories = [
    {
      title: 'Iced Teas',
      image: icedTea,
      description: 'Cool and refreshing iced teas crafted with premium leaves and natural flavors',
      items: ['Classic Iced Green Tea', 'Passion Fruit Iced Tea', 'Peach Hibiscus Cooler', 'Mint Lemonade Tea'],
    },
    {
      title: 'Herbal Drinks',
      image: herbalTea,
      description: 'Soothing herbal infusions made from nature\'s finest botanicals',
      items: ['Chamomile Dream', 'Lavender Rose Blend', 'Ginger Turmeric Tonic', 'Rooibos Sunset'],
    },
    {
      title: 'Smoothies',
      image: smoothie,
      description: 'Fresh fruit smoothies bursting with tropical goodness and vitamins',
      items: ['Mango Paradise', 'Berry Bliss', 'Tropical Sunrise', 'Green Goddess'],
    },
    {
      title: 'Coffee & Tea',
      image: coffee,
      description: 'Expertly brewed coffee and traditional teas for the connoisseur',
      items: ['Artisan Pour-Over', 'Creamy Cappuccino', 'Chai Latte', 'Matcha Excellence'],
    },
  ];

  return (
    <section id="menu" className="py-20 md:py-28">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="inline-block text-primary font-medium text-sm uppercase tracking-wider mb-4">
            Our Menu
          </span>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Handcrafted with Love
          </h2>
          <p className="text-lg text-muted-foreground">
            Every drink at SereniTea is carefully crafted using the finest ingredients, 
            delivering a perfect balance of flavor and refreshment.
          </p>
        </div>

        {/* Menu Grid */}
        <div className="grid md:grid-cols-2 gap-8">
          {menuCategories.map((category, index) => (
            <Card
              key={category.title}
              className="group overflow-hidden border-border/50 shadow-card hover:shadow-elevated transition-all duration-300"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="relative h-56 overflow-hidden">
                <img
                  src={category.image}
                  alt={category.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
                <h3 className="absolute bottom-4 left-6 font-display text-2xl font-bold text-foreground">
                  {category.title}
                </h3>
              </div>
              <CardContent className="p-6">
                <p className="text-muted-foreground mb-4">
                  {category.description}
                </p>
                <ul className="space-y-2">
                  {category.items.map((item) => (
                    <li
                      key={item}
                      className="flex items-center gap-2 text-foreground"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-primary flex-shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Note */}
        <p className="text-center text-muted-foreground mt-12 text-sm">
          Visit us to explore our full menu and seasonal specials
        </p>
      </div>
    </section>
  );
};

export default Menu;
