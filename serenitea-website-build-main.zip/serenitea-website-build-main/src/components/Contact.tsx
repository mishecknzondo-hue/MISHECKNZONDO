import { Button } from '@/components/ui/button';
import { MapPin, Phone, Clock, Navigation } from 'lucide-react';

const Contact = () => {
  const contactInfo = [
    {
      icon: MapPin,
      title: 'Location',
      details: ['Serenity Garden', 'Mzuzu City, Malawi'],
    },
    {
      icon: Phone,
      title: 'Phone',
      details: ['0996 82 12 02'],
    },
    {
      icon: Clock,
      title: 'Opening Hours',
      details: ['Tuesday - Sunday', '10:00 AM - 9:00 PM'],
    },
  ];

  return (
    <section id="contact" className="py-20 md:py-28">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16">
          {/* Info */}
          <div>
            <span className="inline-block text-primary font-medium text-sm uppercase tracking-wider mb-4">
              Visit Us
            </span>
            <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-6">
              Come Experience SereniTea
            </h2>
            <p className="text-lg text-muted-foreground leading-relaxed mb-10">
              We're located in the beautiful Serenity Garden, offering easy access 
              and a peaceful setting. Stop by to discover your new favorite drinks 
              and escape the ordinary.
            </p>

            {/* Contact Cards */}
            <div className="space-y-6 mb-10">
              {contactInfo.map((info) => (
                <div
                  key={info.title}
                  className="flex items-start gap-4 p-5 rounded-xl bg-secondary/50 border border-border/50"
                >
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <info.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground mb-1">
                      {info.title}
                    </h3>
                    {info.details.map((detail, index) => (
                      <p key={index} className="text-muted-foreground">
                        {detail}
                      </p>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button variant="default" size="lg" asChild>
                <a
                  href="https://maps.google.com/?q=Serenity+Garden+Mzuzu+Malawi"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="gap-2"
                >
                  <Navigation className="w-4 h-4" />
                  Get Directions
                </a>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <a href="tel:+265996821202" className="gap-2">
                  <Phone className="w-4 h-4" />
                  Call Us
                </a>
              </Button>
            </div>
          </div>

          {/* Map Placeholder */}
          <div className="relative">
            <div className="aspect-[4/3] lg:aspect-square rounded-2xl overflow-hidden bg-muted shadow-elevated">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d31099.24508374851!2d34.00!3d-11.45!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTHCsDI3JzAwLjAiUyAzNMKwMDAnMDAuMCJF!5e0!3m2!1sen!2smw!4v1234567890"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="SereniTea Café Location"
                className="grayscale-[30%] contrast-[1.1]"
              />
            </div>
            {/* Location Badge */}
            <div className="absolute bottom-4 left-4 right-4 bg-card/95 backdrop-blur-sm p-4 rounded-xl shadow-card">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                  <MapPin className="w-5 h-5 text-primary-foreground" />
                </div>
                <div>
                  <p className="font-semibold text-foreground">SereniTea Café</p>
                  <p className="text-sm text-muted-foreground">Serenity Garden, Mzuzu</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
