import { Leaf, Coffee, Heart, Sparkles } from 'lucide-react';
import cafeInterior from '@/assets/cafe-interior.jpg';

const About = () => {
  const features = [
    {
      icon: Leaf,
      title: 'Natural Ingredients',
      description: 'Fresh, locally-sourced ingredients in every drink',
    },
    {
      icon: Coffee,
      title: 'Artisan Brewing',
      description: 'Handcrafted beverages made with care',
    },
    {
      icon: Heart,
      title: 'Warm Hospitality',
      description: 'Friendly service in a welcoming space',
    },
    {
      icon: Sparkles,
      title: 'Serene Ambience',
      description: 'A peaceful escape from the everyday',
    },
  ];

  return (
    <section id="about" className="py-20 md:py-28 bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Image */}
          <div className="relative order-2 lg:order-1">
            <div className="aspect-square rounded-2xl overflow-hidden shadow-elevated">
              <img
                src={cafeInterior}
                alt="SereniTea Café cozy interior with plants and warm lighting"
                className="w-full h-full object-cover transition-transform duration-700 hover:scale-105"
              />
            </div>
            {/* Decorative Elements */}
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-primary/10 rounded-2xl -z-10" />
            <div className="absolute -top-6 -left-6 w-24 h-24 bg-highlight/10 rounded-2xl -z-10" />
          </div>

          {/* Content */}
          <div className="order-1 lg:order-2">
            <span className="inline-block text-primary font-medium text-sm uppercase tracking-wider mb-4">
              About Us
            </span>
            <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-6">
              Your Serene Escape in Mzuzu City
            </h2>
            <p className="text-lg text-muted-foreground leading-relaxed mb-8">
              Nestled in the heart of Serenity Garden, SereniTea Café offers a tranquil retreat 
              where quality meets comfort. Our café is more than just a place for drinks—it's 
              a sanctuary designed for relaxation, connection, and memorable moments.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-10">
              Whether you're seeking a quiet corner to unwind, a vibrant space to catch up 
              with friends, or an inspiring atmosphere to fuel your creativity, SereniTea 
              welcomes you with open arms and exceptional beverages.
            </p>

            {/* Features Grid */}
            <div className="grid grid-cols-2 gap-6">
              {features.map((feature, index) => (
                <div
                  key={feature.title}
                  className="group"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0 transition-colors group-hover:bg-primary/20">
                      <feature.icon className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground mb-1">
                        {feature.title}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {feature.description}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
