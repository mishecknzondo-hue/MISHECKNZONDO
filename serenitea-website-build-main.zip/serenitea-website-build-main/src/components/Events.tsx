import { Button } from '@/components/ui/button';
import { Calendar, Music, Utensils, Clock } from 'lucide-react';
import jazzNight from '@/assets/jazz-night.jpg';

const Events = () => {
  const eventDetails = [
    { icon: Calendar, text: 'Every Saturday Evening' },
    { icon: Clock, text: 'Starting at 7:00 PM' },
    { icon: Music, text: 'Live Jazz Performances' },
    { icon: Utensils, text: 'Special Dinner Menu' },
  ];

  return (
    <section id="events" className="py-20 md:py-28 bg-accent/5">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div>
            <span className="inline-block text-primary font-medium text-sm uppercase tracking-wider mb-4">
              Special Events
            </span>
            <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-6">
              Dinner & Jazz Night
            </h2>
            <p className="text-lg text-muted-foreground leading-relaxed mb-8">
              Join us for an unforgettable evening of soulful jazz melodies and 
              exquisite dining. Our Dinner & Jazz nights transform SereniTea into 
              a sophisticated venue where great music meets exceptional cuisine.
            </p>

            {/* Event Details */}
            <div className="grid grid-cols-2 gap-4 mb-8">
              {eventDetails.map((detail) => (
                <div
                  key={detail.text}
                  className="flex items-center gap-3 p-4 rounded-xl bg-card shadow-soft"
                >
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <detail.icon className="w-5 h-5 text-primary" />
                  </div>
                  <span className="text-sm font-medium text-foreground">
                    {detail.text}
                  </span>
                </div>
              ))}
            </div>

            <p className="text-muted-foreground mb-8">
              Experience the perfect blend of ambient lighting, smooth jazz, and 
              our specially curated menu. Whether it's a date night or a gathering 
              with friends, our Jazz nights promise an experience to remember.
            </p>

            <Button variant="default" size="lg" asChild>
              <a href="#contact" className="gap-2">
                <Calendar className="w-4 h-4" />
                Reserve Your Table
              </a>
            </Button>
          </div>

          {/* Image */}
          <div className="relative">
            <div className="aspect-[4/3] rounded-2xl overflow-hidden shadow-elevated">
              <img
                src={jazzNight}
                alt="Dinner and Jazz Night at SereniTea Café"
                className="w-full h-full object-cover"
              />
            </div>
            {/* Floating Badge */}
            <div className="absolute -bottom-4 -left-4 md:bottom-8 md:left-auto md:-right-4 bg-card px-6 py-4 rounded-xl shadow-elevated">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-highlight/20 flex items-center justify-center">
                  <Music className="w-6 h-6 text-highlight" />
                </div>
                <div>
                  <p className="font-display font-semibold text-foreground">Live Music</p>
                  <p className="text-sm text-muted-foreground">Every Saturday</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Events;
