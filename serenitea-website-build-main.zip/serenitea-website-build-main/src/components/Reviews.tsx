import { Star, Quote } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const Reviews = () => {
  const reviews = [
    {
      name: 'Sarah M.',
      rating: 5,
      text: 'The best café experience in Mzuzu! The iced teas are absolutely refreshing and the ambience is perfect for both work and relaxation.',
    },
    {
      name: 'James K.',
      rating: 5,
      text: 'Finally, a place that understands quality drinks. The staff is incredibly friendly and the Jazz nights are a must-attend event.',
    },
    {
      name: 'Patricia N.',
      rating: 5,
      text: 'SereniTea has become my go-to spot. The smoothies are heavenly and the interior design makes you feel like you\'re in a tropical paradise.',
    },
  ];

  return (
    <section className="py-20 md:py-28 bg-secondary/30">
      <div className="container mx-auto px-4">
        {/* Header with Rating */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="inline-block text-primary font-medium text-sm uppercase tracking-wider mb-4">
            Customer Reviews
          </span>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-6">
            What Our Guests Say
          </h2>
          
          {/* Overall Rating */}
          <div className="inline-flex items-center gap-4 px-6 py-3 rounded-full bg-card shadow-soft">
            <div className="flex items-center gap-1">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-5 h-5 fill-highlight text-highlight" />
              ))}
            </div>
            <span className="font-display text-2xl font-bold text-foreground">5.0</span>
            <span className="text-muted-foreground">/5 Rating</span>
          </div>
        </div>

        {/* Reviews Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {reviews.map((review, index) => (
            <Card
              key={index}
              className="relative border-border/50 shadow-card hover:shadow-elevated transition-all duration-300"
            >
              <CardContent className="p-6 pt-8">
                {/* Quote Icon */}
                <div className="absolute -top-4 left-6">
                  <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
                    <Quote className="w-4 h-4 text-primary-foreground" />
                  </div>
                </div>

                {/* Rating */}
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-highlight text-highlight" />
                  ))}
                </div>

                {/* Review Text */}
                <p className="text-foreground leading-relaxed mb-4">
                  "{review.text}"
                </p>

                {/* Reviewer Name */}
                <p className="font-semibold text-primary">— {review.name}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Reviews;
