import { useState } from 'react';
import heroImage from '@/assets/hero-drinks.jpg';
import cafeInterior from '@/assets/cafe-interior.jpg';
import icedTea from '@/assets/iced-tea.jpg';
import smoothie from '@/assets/smoothie.jpg';
import coffee from '@/assets/coffee.jpg';
import herbalTea from '@/assets/herbal-tea.jpg';

const Gallery = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const galleryImages = [
    { src: heroImage, alt: 'Colorful drinks collection', span: 'col-span-2 row-span-2' },
    { src: cafeInterior, alt: 'Cozy café interior', span: 'col-span-1 row-span-1' },
    { src: icedTea, alt: 'Refreshing iced matcha', span: 'col-span-1 row-span-1' },
    { src: smoothie, alt: 'Tropical fruit smoothie', span: 'col-span-1 row-span-1' },
    { src: coffee, alt: 'Artisan pour-over coffee', span: 'col-span-1 row-span-1' },
    { src: herbalTea, alt: 'Herbal tea with flowers', span: 'col-span-2 row-span-1' },
  ];

  return (
    <section id="gallery" className="py-20 md:py-28">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="inline-block text-primary font-medium text-sm uppercase tracking-wider mb-4">
            Gallery
          </span>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Moments at SereniTea
          </h2>
          <p className="text-lg text-muted-foreground">
            A glimpse into our world of handcrafted drinks, warm ambience, 
            and unforgettable experiences.
          </p>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {galleryImages.map((image, index) => (
            <div
              key={index}
              className={`${image.span} relative group overflow-hidden rounded-xl cursor-pointer`}
              onClick={() => setSelectedImage(image.src)}
            >
              <img
                src={image.src}
                alt={image.alt}
                className="w-full h-full object-cover min-h-[200px] transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-foreground/0 group-hover:bg-foreground/20 transition-colors duration-300" />
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="w-12 h-12 rounded-full bg-background/90 flex items-center justify-center">
                  <svg className="w-6 h-6 text-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7" />
                  </svg>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {selectedImage && (
        <div
          className="fixed inset-0 z-50 bg-foreground/90 flex items-center justify-center p-4"
          onClick={() => setSelectedImage(null)}
        >
          <button
            className="absolute top-4 right-4 text-background hover:text-primary transition-colors"
            onClick={() => setSelectedImage(null)}
          >
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
          <img
            src={selectedImage}
            alt="Gallery image"
            className="max-w-full max-h-[90vh] object-contain rounded-lg"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </section>
  );
};

export default Gallery;
